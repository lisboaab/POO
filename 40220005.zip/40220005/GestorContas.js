import * as ContaBancaria from "./ContaBancaria.js";

export let contaBancaria = []

export function criarConta(numero,nome,valor){
  contaBancaria.forEach(conta => {
    if((conta.numero) === numero){
      alert("Número de conta já existente")
    }
    else {
      let novaConta = new ContaBancaria(numero,nome,valor)
      contaBancaria.push(novaConta)
      console.log("Conta criada")
    }
  });
}

export function realizarDeposito(numeroConta, valor){
  let conta = contaBancaria.find(conta => conta.numero === numeroConta)
  if(conta){
    ContaBancaria.depositar(valor)
  }
  else {
    alert("Conta não existe")
  }
}

export function realizarLevantamento(numero,valor){
  let conta = contaBancaria.find(conta => conta.numero === numero)
  if (conta){
    conta.levantar(valor)
  }
  else {
    alert("Conta não existe")
  }
}

export function exibirSaldo(numeroConta){
  let conta = contaBancaria.find(conta => conta.numero === numeroConta)
  if(conta){
    alert(`Saldo: ${conta.saldo}`)
  }
  else {
    alert("Conta não existe")
  }
}


export function listarContas(){
  console.log("Listado!")
  contaBancaria.forEach((conta) => {
    let tabela = document.getElementById("tabelaContas")
    let line = `<tr><td>${conta.numero}</td><td>${conta.nome}</td><td>${conta.saldo}</td></tr>`
    tabela.innerHTML += line
  })
}