import * as GestorContas from "./GestorContas.js";

// ADD CONTA
let numero = document.getElementById("numeroContaInput").value;
let nome = document.getElementById("nomeTitularInput").value;
let btnCriarConta = document.getElementById("btnCriarConta");
btnCriarConta.addEventListener("click", GestorContas.criarConta(nome,numero));


//REALIZAR DEPÓSITO
let numeroConta = document.getElementById("depositoNumeroContaInput").value;
let valor = document.getElementById("valorDepositoInput").value;
document.getElementById("btnRealizarDeposito").addEventListener("click", GestorContas.realizarDeposito(numeroConta, valor))

// REALIZAR LEVANTAMENTO
let levantamentoNumeroContaInput = document.getElementById("levantamentoNumeroContaInput").value;
let valorLevantamentoInput = document.getElementById("valorLevantamentoInput").value;
document.getElementById("btnRealizarLevantamento").addEventListener("click", GestorContas.realizarLevantamento(levantamentoNumeroContaInput,valorLevantamentoInput))


// EXIBIR SALDO
let saldoNumeroContaInput = document.getElementById("saldoNumeroContaInput").value;
document.getElementById("btnExibirSaldo").addEventListener("click", GestorContas.exibirSaldo(saldoNumeroContaInput))


// TABELA
let btnTabela = document.getElementById("btnListarContas");
btnTabela.addEventListener("click", GestorContas.listarContas)




